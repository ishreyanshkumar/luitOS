/* PROCESSES, SCHEDULING, SMP. */
#include "types.h"
#include "defs.h"
#include "hal.h"
#include "pstat.h"
#include "usysinfo.h"
#include "schedinfo.h"

struct cpu   cpus[NCPU];
struct proc  proc[NPROC];

/* KERNEL STACKS.
 *
 * BUG WORTH UNDERSTANDING (we hit it building this reference kernel):
 * do NOT build a 4-page kernel stack by calling palloc() four times. palloc()
 * returns pages from a free list - they are NOT contiguous. The stack would run
 * off the end of the first page into memory that is still on the free list,
 * which palloc() then happily hands to someone else. In our case it handed out
 * a page of the kernel's own page table, the stack overwrote it, and we got a
 * load page fault in an address that "was definitely mapped."
 *
 * A kernel stack must be CONTIGUOUS. Carve it out of BSS, where the linker
 * guarantees that.
 */
#define KSTACK_PAGES 4
#define KSTACK_SIZE  (KSTACK_PAGES * PGSIZE)
static char kstacks[NPROC][KSTACK_SIZE] __attribute__((aligned(4096)));
static struct spinlock pid_lock;
static struct spinlock wait_lock;   /* protects parent pointers */
static struct spinlock stride_lock; /* serializes global stride selection */
static uint64 stride_floor;         /* pass value of the most recently selected minimum */
static int   nextpid = 1;
struct proc *initproc;

extern void forkret_asm(void);

/* Lab 7 helpers may be added only inside this region. */
/* LAB7-HELPERS-BEGIN */
/* LAB7-HELPERS-END */

/* Reads are lock-free because the word is naturally aligned on RV64.  The
 * atomic builtin also tells the compiler that this value may change on another hart. */
static uint64
stride_floor_snapshot(void)
{
    return __atomic_load_n(&stride_floor, __ATOMIC_RELAXED);
}

static void __attribute__((unused))
stride_floor_publish(uint64 value)
{
    __atomic_store_n(&stride_floor, value, __ATOMIC_RELAXED);
}

/* tp holds the hart id (set in entry.S). Safe only with interrupts off -
 * otherwise we could be moved to another hart between read and use. */
struct cpu *mycpu(void) { return &cpus[hal_hart_id()]; }

struct proc *myproc(void)
{
    push_off();
    struct proc *p = mycpu()->proc;
    pop_off();
    return p;
}

static int allocpid(void)
{
    acquire(&pid_lock);
    int pid = nextpid++;
    release(&pid_lock);
    return pid;
}

void procinit(void)
{
    initlock(&pid_lock,  "nextpid");
    initlock(&wait_lock, "wait_lock");
    initlock(&stride_lock, "stride_sched");
    stride_floor = 0;
    initlock(&tickslock, "time");
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
        initlock(&p->lock, "proc");
        p->state  = UNUSED;
        p->kstack = 0;
    }
}

static void freeproc(struct proc *p)
{
    /* USYSINFO_VA is above p->sz; its backing page must be removed first. */
    usysinfo_free(p);
    if (p->tf) pfree((void *)p->tf);
    p->tf = 0;
    if (p->pagetable) uvmfree(p->pagetable, p->sz);
    p->pagetable = 0;
    p->kstack = 0;              /* statically allocated - nothing to free */
    p->sz = 0; p->heapbase = 0; p->pid = 0; p->parent = 0;
    p->name[0] = 0; p->chan = 0; p->killed = 0; p->xstate = 0;
    p->trace_filter = 0;
    p->syscall_count = 0; p->ctxsw_count = 0; p->state_gen = 0;
    p->sched_tickets = 0; p->sched_stride = 0; p->sched_pass = 0;
    p->sched_dispatches = 0; p->sched_last_hart = -1; p->sched_migrations = 0;
    p->state = UNUSED;
}

/* First thing a brand-new process runs. It must release the lock scheduler()
 * acquired for us - a subtlety that trips up everyone the first time. */
static void forkret(void)
{
    static int first = 1;
    release(&myproc()->lock);
    if (first) {
        /* The filesystem cannot be initialized from main(): reading the
         * superblock SLEEPS on disk I/O, and only a process can sleep.
         * So the first process to run does it, exactly once. */
        first = 0;
        fsinit(ROOTDEV);
        myproc()->cwd = namei("/");
        __sync_synchronize();
    }
    usertrapret();
}

static struct proc *allocproc(void)
{
    struct proc *p;
    for (p = proc; p < &proc[NPROC]; p++) {
        acquire(&p->lock);
        if (p->state == UNUSED) goto found;
        release(&p->lock);
    }
    return 0;

found:
    p->pid    = allocpid();
    p->state  = USED;
    p->killed = 0;
    p->xstate = 0;
    p->chan   = 0;
    p->trace_filter = 0;
    p->usysinfo = 0;
    p->syscall_count = 0;
    p->ctxsw_count = 0;
    p->state_gen = 0;
    p->heapbase = 0;

    /* TODO-BEGIN S1: initialize all Lab 7 scheduler state for a fresh slot.
     * A newly allocated process must not receive an artificial pass advantage. */
    p->sched_tickets = STRIDE_DEFAULT_TICKETS;
    p->sched_stride = STRIDE_BIG / STRIDE_DEFAULT_TICKETS;
    p->sched_pass = stride_floor_snapshot();
    p->sched_dispatches = 0;
    p->sched_last_hart = -1;
    p->sched_migrations = 0;
    /* TODO-END S1 */

    if ((p->tf = (struct trapframe *)palloc()) == 0) { freeproc(p); release(&p->lock); return 0; }

    /* Contiguous, statically reserved. See the note at the top of this file. */
    p->kstack = (uint64)kstacks[p - proc];

    p->pagetable = uvmcreate();
    if (!p->pagetable) { freeproc(p); release(&p->lock); return 0; }
    if (usysinfo_setup(p) < 0) { freeproc(p); release(&p->lock); return 0; }

    memset(&p->context, 0, sizeof(p->context));
    p->context.ra = (uint64)forkret;
    p->context.sp = p->kstack + KSTACK_SIZE;
    return p;
}

/* --- the very first user process, built by hand --- */
extern char _binary_user_initcode_start[], _binary_user_initcode_end[];

void userinit(void)
{
    struct proc *p = allocproc();
    if (!p) panic("userinit: allocproc failed");
    initproc = p;

    uint64 sz = (uint64)(_binary_user_initcode_end - _binary_user_initcode_start);
    if (sz > PGSIZE) panic("userinit: initcode too big");

    char *mem = palloc();
    memset(mem, 0, PGSIZE);
    memmove(mem, _binary_user_initcode_start, sz);
    mappages(p->pagetable, 0, PGSIZE, (uint64)mem, PTE_R | PTE_W | PTE_X | PTE_U);

    char *stack = palloc();
    memset(stack, 0, PGSIZE);
    mappages(p->pagetable, PGSIZE, PGSIZE, (uint64)stack, PTE_R | PTE_W | PTE_U);

    p->sz       = 2 * PGSIZE;
    p->heapbase = p->sz;               /* heap begins above the initial stack */
    p->tf->epc  = 0;                    /* start at the first byte of initcode */
    p->tf->sp   = 2 * PGSIZE;           /* stack grows down from the top       */
    strncpy(p->name, "initcode", sizeof(p->name));
    /* p->cwd is set by forkret once the filesystem is initialized. */
    p->state    = RUNNABLE;
    release(&p->lock);
}

int growproc(int n)
{
    /* TODO-BEGIN K1
     * Convert sbrk() from eager allocation to lazy reservation.
     *
     * The supplied starter body below is the old eager implementation so that
     * the checkpoint still boots and passes the earlier-course regressions.
     * Replace it with a correct lazy implementation.
     *
     * Required behavior:
     *   - n > 0: change p->sz only; do not allocate a physical page and do not
     *     install a PTE. Reject overflow and growth into USYSINFO_VA.
     *   - n < 0: never shrink below p->heapbase. Unmap/free only complete pages
     *     that leave the heap. Missing PTEs are legitimate lazy holes.
     *   - n == 0: succeed without changing the address space.
     *   - p->heapbase is supplied by the checkpoint and must not be changed.
     *
     * Keep all Lab 4 K1 code between these markers.
     */
    struct proc *p = myproc();
    uint64 sz = p->sz;

    if (n > 0) {
        uint64 newsz = sz + (uint64)n;
        if (newsz < sz || newsz > USYSINFO_VA)
            return -1;
        p->sz = newsz;
        return 0;
    }

    if (n < 0) {
        uint64 dec = (uint64)(-(int64)n);
        if (dec > sz || sz - dec < p->heapbase)
            return -1;

        uint64 newsz = sz - dec;
        uint64 oldtop = PGROUNDUP(sz);
        uint64 newtop = PGROUNDUP(newsz);
        if (newtop < oldtop)
            uvmunmap(p->pagetable, newtop,
                     (oldtop - newtop) / PGSIZE, 1);
        p->sz = newsz;
        return 0;
    }

    return 0;
    /* TODO-END K1 */
}

int fork(void)
{
    struct proc *parent = myproc();
    struct proc *np = allocproc();
    if (!np) return -1;

    /* EAGER COPY: every user page is duplicated, right now. Simple, correct,
     * and O(memory) even for fork+exec - which is why Lab 5 replaces this
     * with copy-on-write. Do not bring COW forward; the graders diff it. */
    if (uvmcopy(parent->pagetable, np->pagetable, parent->sz) < 0) {
        freeproc(np);
        release(&np->lock);
        return -1;
    }
    np->sz = parent->sz;
    np->heapbase = parent->heapbase;
    *(np->tf) = *(parent->tf);
    np->tf->a0 = 0;                 /* the child sees fork() return 0 */

    /* The child INHERITS the parent's open files and cwd - this is what makes
     * `cmd > file` work: the shell redirects, then forks, and the child keeps
     * the redirected descriptor. Same struct file, same offset. */
    for (int i = 0; i < NOFILE; i++)
        if (parent->ofile[i])
            np->ofile[i] = filedup(parent->ofile[i]);
    np->cwd = idup(parent->cwd);

    strncpy(np->name, parent->name, sizeof(np->name));

    /* TODO-BEGIN S2: inherit proportional-share policy without inheriting
     * accumulated history.  Set tickets/stride and a sensible initial pass;
     * reset Lab 7 statistics for the child. */
    uint64 floor = stride_floor_snapshot();
    np->sched_tickets = parent->sched_tickets;
    np->sched_stride = parent->sched_stride;
    np->sched_pass = parent->sched_pass > floor ? parent->sched_pass : floor;
    np->sched_dispatches = 0;
    np->sched_last_hart = -1;
    np->sched_migrations = 0;
    /* TODO-END S2 */

    trace_fork(parent, np);          /* completed Lab 2 semantics */
    int pid = np->pid;
    release(&np->lock);

    acquire(&wait_lock);
    np->parent = parent;
    release(&wait_lock);

    acquire(&np->lock);
    np->state = RUNNABLE;
    release(&np->lock);
    return pid;
}

int
set_tickets(int tickets)
{
    /* TODO-BEGIN S3: validate and atomically update the current process policy.
     * Keep accumulated pass unchanged so a ticket change does not erase history. */
    if (tickets < STRIDE_MIN_TICKETS || tickets > STRIDE_MAX_TICKETS)
        return -1;

    struct proc *p = myproc();
    acquire(&p->lock);
    p->sched_tickets = tickets;
    p->sched_stride = STRIDE_BIG / tickets;
    release(&p->lock);
    return 0;
    /* TODO-END S3 */
}

int
get_schedinfo(uint64 uaddr)
{
    struct proc *p = myproc();
    struct schedinfo out;

    acquire(&p->lock);
    out.pid = p->pid;
    out.tickets = p->sched_tickets;
    out.stride = p->sched_stride;
    out.pass = p->sched_pass;
    out.dispatches = p->sched_dispatches;
    out.last_hart = p->sched_last_hart;
    out.migrations = p->sched_migrations;
    release(&p->lock);

    if (copyout(p->pagetable, uaddr, (char *)&out, sizeof(out)) < 0)
        return -1;
    return 0;
}


static void reparent(struct proc *p)
{
    for (struct proc *pp = proc; pp < &proc[NPROC]; pp++) {
        if (pp->parent == p) {
            pp->parent = initproc;
            wakeup(initproc);
        }
    }
}

void exit(int status)
{
    struct proc *p = myproc();
    if (p == initproc) panic("init exiting");

    /* Close every open file. Do this BEFORE becoming a zombie: fileclose may
     * sleep (iput -> disk I/O), and zombies must never sleep. */
    for (int fd = 0; fd < NOFILE; fd++) {
        if (p->ofile[fd]) {
            fileclose(p->ofile[fd]);
            p->ofile[fd] = 0;
        }
    }
    iput(p->cwd);
    p->cwd = 0;

    acquire(&wait_lock);
    reparent(p);
    wakeup(p->parent);
    acquire(&p->lock);
    p->xstate = status;
    p->state  = ZOMBIE;
    release(&wait_lock);

    sched();                        /* never returns */
    panic("zombie exit");
}

int wait(uint64 addr)
{
    struct proc *p = myproc();
    acquire(&wait_lock);

    for (;;) {
        int havekids = 0;
        for (struct proc *pp = proc; pp < &proc[NPROC]; pp++) {
            if (pp->parent != p) continue;
            havekids = 1;
            acquire(&pp->lock);
            if (pp->state == ZOMBIE) {
                int pid = pp->pid;
                if (addr && copyout(p->pagetable, addr,
                                    (char *)&pp->xstate, sizeof(pp->xstate)) < 0) {
                    release(&pp->lock);
                    release(&wait_lock);
                    return -1;
                }
                freeproc(pp);
                release(&pp->lock);
                release(&wait_lock);
                return pid;
            }
            release(&pp->lock);
        }
        if (!havekids || p->killed) {
            release(&wait_lock);
            return -1;
        }
        sleep(p, &wait_lock);
    }
}

/* --- the scheduler: one instance per hart (L9) --- */
static struct proc *
stride_pick_next(struct cpu *c)
{
    /* TODO-BEGIN S4: implement the global SMP-safe stride selection.
     * Return 0 if no process is runnable.  Otherwise return one RUNNING process
     * with that process's lock still held and stride_lock already released. */
    int hart = (int)(c - cpus);

    acquire(&stride_lock);

    struct proc *best = 0;
    uint64 best_pass = 0;
    int best_hart = -1;
    int best_pid = 0;

    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
        acquire(&p->lock);
        if (p->state == RUNNABLE) {
            int better = 0;
            if (best == 0) {
                better = 1;
            } else if (p->sched_pass < best_pass) {
                better = 1;
            } else if (p->sched_pass == best_pass) {
                int p_aff = (p->sched_last_hart == hart);
                int b_aff = (best_hart == hart);
                if (p_aff && !b_aff) {
                    better = 1;
                } else if (p_aff == b_aff) {
                    if (p->pid < best_pid)
                        better = 1;
                }
            }
            if (better) {
                best = p;
                best_pass = p->sched_pass;
                best_hart = p->sched_last_hart;
                best_pid = p->pid;
            }
        }
        release(&p->lock);
    }

    if (best == 0) {
        release(&stride_lock);
        return 0;
    }

    acquire(&best->lock);
    if (best->state == RUNNABLE) {
        stride_floor_publish(best->sched_pass);
        best->sched_dispatches++;
        if (best->sched_last_hart >= 0 && best->sched_last_hart != hart)
            best->sched_migrations++;
        best->sched_last_hart = hart;
        best->sched_pass += best->sched_stride;
        best->state = RUNNING;
        release(&stride_lock);
        return best;
    }

    release(&best->lock);
    release(&stride_lock);
    return 0;
    /* TODO-END S4 */
}

void scheduler(void)
{
    struct cpu *c = mycpu();
    c->proc = 0;

    for (;;) {
        intr_on();
        struct proc *p = stride_pick_next(c);
        if (p == 0)
            continue;

        /* The context-switch mechanism is supplied.  stride_pick_next() returns
         * p with p->lock held, exactly as the original scheduler required. */
        c->proc = p;
        w_satp(MAKE_SATP(p->pagetable));
        sfence_vma();

        p->ctxsw_count++;
        p->state_gen++;
        usysinfo_update(p);

        swtch(&c->context, &p->context);

        w_satp(MAKE_SATP(kernel_pagetable));
        sfence_vma();
        c->proc = 0;
        release(&p->lock);
    }
}

/* Switch to the scheduler. Must hold p->lock and have changed p->state. */
void sched(void)
{
    struct proc *p = myproc();
    if (!holding(&p->lock))   panic("sched: not holding p->lock");
    if (mycpu()->noff != 1)   panic("sched: holding another lock too");
    if (p->state == RUNNING)  panic("sched: process is still RUNNING");
    if (intr_get())           panic("sched: interrupts are on");

    int intena = mycpu()->intena;
    swtch(&p->context, &mycpu()->context);
    mycpu()->intena = intena;
}

void yield(void)
{
    struct proc *p = myproc();
    acquire(&p->lock);
    p->state = RUNNABLE;
    sched();
    release(&p->lock);
}

void sleep(void *chan, struct spinlock *lk)
{
    struct proc *p = myproc();

    /* Acquire p->lock BEFORE releasing lk. If we did it the other way round, a
     * wakeup could slip in between and be lost - the classic missed-wakeup race. */
    acquire(&p->lock);
    release(lk);

    p->chan  = chan;
    p->state = SLEEPING;
    sched();

    p->chan = 0;
    release(&p->lock);
    acquire(lk);
}

void wakeup(void *chan)
{
    /* TODO-BEGIN S5: preserve wakeup semantics and clamp a waking process so
     * stale pass cannot buy a long catch-up burst after sleeping. */
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
        if (p != myproc()) {
            acquire(&p->lock);
            if (p->state == SLEEPING && p->chan == chan) {
                uint64 floor = stride_floor_snapshot();
                if (p->sched_pass < floor)
                    p->sched_pass = floor;
                p->state = RUNNABLE;
            }
            release(&p->lock);
        }
    }
    /* TODO-END S5 */
}

int kill(int pid)
{
    /* TODO-BEGIN S6: keep kill() correct under Lab 7.  If kill wakes a sleeping
     * process, apply the same pass-clamping rule as wakeup(). */
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
        acquire(&p->lock);
        if (p->pid == pid) {
            p->killed = 1;
            if (p->state == SLEEPING) {
                uint64 floor = stride_floor_snapshot();
                if (p->sched_pass < floor)
                    p->sched_pass = floor;
                p->state = RUNNABLE;
            }
            release(&p->lock);
            return 0;
        }
        release(&p->lock);
    }
    return -1;
    /* TODO-END S6 */
}

/* Copy up to max process records to user space; returns the count. Backs the
 * procstat() syscall and the `ps` utility. Reads are racy-by-design (a
 * snapshot, not a transaction) but each slot is read under its own lock. */
int procstat(uint64 uaddr, int max)
{
    struct pstat ps;
    int n = 0;
    for (struct proc *p = proc; p < &proc[NPROC] && n < max; p++) {
        acquire(&p->lock);
        if (p->state == UNUSED) { release(&p->lock); continue; }
        ps.pid   = p->pid;
        ps.state = p->state;
        memmove(ps.name, p->name, sizeof(ps.name));
        release(&p->lock);
        if (copyout(myproc()->pagetable, uaddr + n * sizeof(ps),
                    (char *)&ps, sizeof(ps)) < 0)
            return -1;
        n++;
    }
    return n;
}

void procdump(void)
{
    static const char *st[] = {
        [UNUSED]"unused", [USED]"used", [SLEEPING]"sleep",
        [RUNNABLE]"runble", [RUNNING]"run", [ZOMBIE]"zombie"
    };
    printf("\n--- process table ---\n");
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
        if (p->state == UNUSED) continue;
        printf("pid %d %s %s\n", p->pid, st[p->state], p->name);
    }
}
